package com.example.laboratorio05.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.laboratorio05.R;
import com.example.laboratorio05.ToolPicasso.PiccasoIMG;
import com.example.laboratorio05.data.championsLol;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyHolder> {


    Context c;
    ArrayList<championsLol> champs;


    public MyAdapter(Context c, ArrayList<championsLol> champs) {
        this.c = c;
        this.champs = champs;
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main,parent,false);
        MyHolder holder = new MyHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        holder.nameTxt.setText(champs.get(position).getName());

        PiccasoIMG.downloadImage(c, champs.get(position).getUrl(),holder.img);
    }

    @Override
    public int getItemCount() {
        return champs.size();
    }
}
