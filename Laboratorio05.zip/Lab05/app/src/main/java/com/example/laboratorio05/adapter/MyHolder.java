package com.example.laboratorio05.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.laboratorio05.R;

public class MyHolder extends RecyclerView.ViewHolder{

    TextView nameTxt;
    ImageView img;

    public MyHolder(View itemView){
        super(itemView);

        nameTxt = (TextView) itemView.findViewById(R.id.item_title);
        img = (ImageView) itemView.findViewById(R.id.item_image);
    }
}
