package com.example.laboratorio05.data;

import java.util.ArrayList;

public class championsLolCollection {

    public static ArrayList<championsLol> getChampsLol(){
        ArrayList<championsLol> champs = new ArrayList<>();
        championsLol lol = new championsLol();

        lol.setName("Garen");
        lol.setUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/Collage_of_Six_Cats-02.jpg/1200px-Collage_of_Six_Cats-02.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Shen");
        lol.setUrl("https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Shen_0.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Belveth");
        lol.setUrl("https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/blt47283ab0b0f477bc/6286a55abde8395bd0123e15/BELVETH-Final-copy.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Fiddlesticks");
        lol.setUrl("https://images.contentstack.io/v3/assets/blt731acb42bb3d1659/blteafcbfed69c501b5/61e2114879b5bd5a1ef7b2ea/011422_Fiddlesticks_Splash_v1.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Vex");
        lol.setUrl("https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Vex_0.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Swain");
        lol.setUrl("https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Swain_0.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Twitch");
        lol.setUrl("https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Twitch_0.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Seraphine");
        lol.setUrl("https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Seraphine_0.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Janna");
        lol.setUrl("https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Janna_0.jpg");
        champs.add(lol);

        lol = new championsLol();
        lol.setName("Zyra");
        lol.setUrl("https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Zyra_0.jpg");
        champs.add(lol);

        return champs;
    }
}
