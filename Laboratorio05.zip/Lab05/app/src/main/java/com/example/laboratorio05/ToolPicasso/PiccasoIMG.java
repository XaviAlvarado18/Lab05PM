package com.example.laboratorio05.ToolPicasso;

import android.content.Context;
import android.widget.ImageView;

import com.example.laboratorio05.R;
import com.squareup.picasso.Picasso;

public class PiccasoIMG {

    public static void downloadImage(Context c, String url, ImageView img){


        if(url != null && url.length()>0){
            Picasso.with(c).load(url).placeholder(R.drawable.lol).into(img);
        }else{
            Picasso.with(c).load(R.drawable.lol).into(img);
        }
    }



}
