package com.example.laboratorio05.data;

public class championsLol {

    String name;
    String url;

    public championsLol(){

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
